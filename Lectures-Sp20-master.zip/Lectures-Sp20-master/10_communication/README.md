# Week 10: Data Science Communication & The Future

## Monday : Guest Lecture II

- [Video](Coming Soon)
- [Slides](Coming Soon)
- Quiz: 

## Wednesday: Data Science Communication

- [Video](Coming Soon)
- [Slides](Coming Soon)
- Quiz: 


## Friday: The Future of Data Science

- [Video](Coming Soon)
- [Slides](Coming Soon)
