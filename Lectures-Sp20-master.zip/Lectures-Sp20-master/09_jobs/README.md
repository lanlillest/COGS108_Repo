# Week 9: Dimensionality Reduction & Data Science Jobs

## Monday : No Class

## Wednesday: Dimensionality Reduction

- [Video](Coming Soon)
- [Slides](Coming Soon)
- Quiz: 


## Friday: Data Science Jobs

- [Video](Coming Soon)
