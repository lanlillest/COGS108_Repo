

# Week 1: Data Science

## Monday : Welcome!

**01_01_welcome**
- [Video](https://youtu.be/zMmMakbEclM)
- [Slides](https://github.com/COGS108/Lectures-Sp20/tree/master/01_data_science/01_01_welcome.pdf)

## Wednesday: Introduction to Data Science

**01_02_data_science**
- [Video](https://youtu.be/wRjjilKQY8U)
- [Slides](https://github.com/COGS108/Lectures-Sp20/tree/master/01_data_science/01_02_data_science.pdf)

## Friday: Data Science Ethics

**01_03_ethicsI**
- [Video](https://youtu.be/5IZK05vmVuw)
- [Slides](https://github.com/COGS108/Lectures-Sp20/tree/master/01_data_science/01_03_ethicsI.pdf)

**01_04_ethicsII**
- [Video](https://youtu.be/7MY9lLlFI58)
- [Slides](https://github.com/COGS108/Lectures-Sp20/tree/master/01_data_science/01_04_ethicsII.pdf)