# Week 5: Inference

## Monday : Inference I

- [Video](Coming Soon)
- [Slides](Coming Soon)
- Quiz: 

## Wednesday: Inference I

- [Video](Coming Soon)
- [Slides](Coming Soon)
- Quiz: 


## Friday: Inference III

- [Video](Coming Soon)
- [Notebook](Coming Soon)
