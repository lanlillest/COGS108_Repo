# Week 8: Nonparametric & Geospatial Analysis

## Monday : Nonparametric Analysis

- [Video](Coming Soon)
- [Slides](Coming Soon)
- Quiz: 

## Wednesday: Geospatial Analysis I

- [Video](Coming Soon)
- [Slides](Coming Soon)
- Quiz: 


## Friday: Geospatial Analysis II

- [Video](Coming Soon)
- [Notebook](Coming Soon)
