# Week 4: Data Analysis

## Monday : Intro to Analysis

- [Video](Coming Soon)
- [Slides](Coming Soon)
- Quiz: 

## Wednesday: EDA

- [Video](Coming Soon)
- [Slides](Coming Soon)
- Quiz: 


## Friday: Dataviz II

- [Video](Coming Soon)
- [Notebook](Coming Soon)
