# Week 7: Machine Learning

## Monday : Machine Learning I

- [Video](Coming Soon)
- [Slides](Coming Soon)
- Quiz: 

## Wednesday: Machine Learning II

- [Video](Coming Soon)
- [Slides](Coming Soon)
- Quiz: 


## Friday: Text + ML

- [Video](Coming Soon)
- [Notebook](Coming Soon)
