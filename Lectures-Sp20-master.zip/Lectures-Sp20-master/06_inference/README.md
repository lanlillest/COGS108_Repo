# Week 6: Text Analysis

## Monday : Text Analysis I

- [Video](Coming Soon)
- [Slides](Coming Soon)
- Quiz: 

## Wednesday: Guest Lecture I

- [Video](Coming Soon)
- [Slides](Coming Soon)
- Quiz: 


## Friday: Text Analysis II

- [Video](Coming Soon)
- [Notebook](Coming Soon)
